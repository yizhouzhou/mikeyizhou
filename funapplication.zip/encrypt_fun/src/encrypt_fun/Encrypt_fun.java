/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encrypt_fun;

/**
 *
 * @author zhouyizhou
 */
public class Encrypt_fun {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        loginform jfrm2 = new loginform();
        jfrm2.setVisible(true);
    }
    
}
